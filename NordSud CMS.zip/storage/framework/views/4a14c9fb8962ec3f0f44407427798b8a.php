<?php echo value($html); ?>

<?php /**PATH D:\PROJECTS\NordSud\NordSud\vendor\filament\support\resources\views/anonymous-partial.blade.php ENDPATH**/ ?>